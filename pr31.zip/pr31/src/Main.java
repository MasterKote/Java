import java.util.Scanner;
import  java.io.*;

public class Main {
    public static void main(String[] args) {
        //Проверить истинность высказывания:
        //"Сумма цифр данного положительного трехзначного числа является четным числом".
        String path = System.getProperty("user.dir") + File.separatorChar + "input1.txt";
        int task1 = 0;
        try (FileReader fr = new FileReader(path))
        {
            BufferedReader br = new BufferedReader(fr);
            String task1s;
            
            while ((task1s = br.readLine()) != null)
            {
                task1 = Integer.parseInt(task1s);
                System.out.println(task1s);
            }
            fr.close();
        }
        catch (IOException ex)
        {
            System.out.println(ex.getMessage());
        }
        try(FileWriter writer = new FileWriter("output1.txt", false))
        {
            if (task1 >= 100 && task1 <= 999)
            {
                int digit1 = (task1 / 100) % 10;
                int digit2 = (task1 / 10) % 10;
                int digit3 = task1 % 10;

                int sum = digit1 + digit2 + digit3;

                if(sum %2 == 0)
                {
                    writer.write("true");
                    System.out.printf("true");
                }
                else
                {
                    writer.write("false");
                    System.out.printf("false");
                }
            }
            writer.flush();
        }
        catch(IOException ex)
        {
            System.out.println(ex.getMessage());
        }

        String path1 = System.getProperty("user.dir") + File.separatorChar + "input2.txt";
        int task2 = 0;
        try (FileReader fr = new FileReader(path))
        {
            BufferedReader br = new BufferedReader(fr);
            String task1s;

            while ((task1s = br.readLine()) != null)
            {
                task1 = Integer.parseInt(task1s);
                System.out.println(task1s);
            }
            fr.close();
        }
        catch (IOException ex)
        {
            System.out.println(ex.getMessage());
        }
        try(FileWriter writer = new FileWriter("output1.txt", false))
        {
            writer.flush();
        }
        catch(IOException ex)
        {
            System.out.println(ex.getMessage());
        }
    }
}