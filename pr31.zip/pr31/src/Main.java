import java.util.Arrays;
import java.util.Scanner;
import  java.io.*;

public class Main {
    public static void main(String[] args) {
        //Проверить истинность высказывания:
        //"Сумма цифр данного положительного трехзначного числа является четным числом".
        System.out.println("Zadanie 1");
        String path = System.getProperty("user.dir") + File.separatorChar + "input1.txt";
        int task1 = 0;
        try (FileReader fr = new FileReader(path))
        {
            BufferedReader br = new BufferedReader(fr);
            String task1s;
            
            while ((task1s = br.readLine()) != null)
            {
                task1 = Integer.parseInt(task1s);
                System.out.println(task1s);
            }
            fr.close();
        }
        catch (IOException ex)
        {
            System.out.println(ex.getMessage());
        }
        try(FileWriter writer = new FileWriter("output1.txt", false))
        {
            if (task1 >= 100 && task1 <= 999)
            {
                int digit1 = (task1 / 100) % 10;
                int digit2 = (task1 / 10) % 10;
                int digit3 = task1 % 10;

                int sum = digit1 + digit2 + digit3;

                if(sum %2 == 0)
                {
                    writer.write("true");
                    System.out.println("true");
                }
                else
                {
                    writer.write("false");
                    System.out.println("false");
                }
            }
            writer.flush();
        }
        catch(IOException ex)
        {
            System.out.println(ex.getMessage());
        }

        System.out.println();

        //Ввести пять различных ненулевых целых чисел.
        //Найти произведение двух наибольших чисел.
        System.out.println("Zadanie 2");
        String path2 = System.getProperty("user.dir") + File.separatorChar + "input2.txt";
        int[] task2 = new int[0];
        try (FileReader fr2 = new FileReader(path2))
        {
            BufferedReader br2 = new BufferedReader(fr2);
            String task2s;

            while ((task2s = br2.readLine()) != null)
            {
                String[] numbers = task2s.split("\\s+");
                task2 = new int[numbers.length];

                for (int i = 0; i < numbers.length; i++)
                {
                    task2[i] = Integer.parseInt(numbers[i].trim());
                }
                System.out.println(task2s);
            }
            fr2.close();
        }
        catch (IOException ex)
        {
            System.out.println(ex.getMessage());
        }
        try(FileWriter writer2 = new FileWriter("output2.txt", false))
        {
            Arrays.sort(task2);
            int task2_1 = task2[3];
            int task2_2 = task2[4];
            writer2.write(task2_1 + " " + task2_2);
            System.out.println("Наибольшие два числа:" + task2[3] + " " + task2[4]);
            writer2.flush();
        }
        catch(IOException ex)
        {
            System.out.println(ex.getMessage());
        }

        System.out.println();

        //Дан целочисленный массив, состоящий из N элементов (N > 0),
        // содержащий, по крайней мере, два нуля.
        // Вычислить сумму чисел из данного набора,
        // расположенных между этими двумя нулями.
        // Если нули идут подряд, то вывести 0.
        // Если в массиве имеется только одно значение 0,
        // то вычислить сумму всех его элементов.
        System.out.println("Zadanie 3");
        String path3 = System.getProperty("user.dir") + File.separatorChar + "input3.txt";
        int[] task3 = new int[0];
        try (FileReader fr3 = new FileReader(path3))
        {
            BufferedReader br3 = new BufferedReader(fr3);
            String task3s;

            while ((task3s = br3.readLine()) != null)
            {
                String[] numbers = task3s.split("\\s+");
                task3 = new int[numbers.length];

                for (int i = 0; i < numbers.length; i++)
                {
                    task3[i] = Integer.parseInt(numbers[i].trim());
                }
                System.out.println(task3s);
            }
            fr3.close();
        }
        catch (IOException ex)
        {
            System.out.println(ex.getMessage());
        }
        try(FileWriter writer3 = new FileWriter("output3.txt", false))
        {
            if (task3.length < 25)
            {
                System.out.println("Длина массива меньше 25!");
                writer3.write("Длина массива меньше 25!");
            }
            else
            {
                int firstZeroIndex = -1;
                int secondZeroIndex = -1;
                int zeroCount = 0;

                for (int i = 0; i < task3.length; i++) {
                    if (task3[i] == 0) {
                        zeroCount++;
                        if (firstZeroIndex == -1) {
                            firstZeroIndex = i;
                        } else if (secondZeroIndex == -1) {
                            secondZeroIndex = i;
                            break;
                        }
                    }
                }

                int result;

                if (zeroCount == 0) {
                    result = 0;
                    System.out.println("В массиве нет нулей");
                    writer3.write("В массиве нет нулей");
                }
                else if (zeroCount == 1) {
                    int sum = 0;
                    for (int num : task3) {
                        sum += num;
                    }
                    result = sum;
                    System.out.println("Только один ноль. Сумма всех элементов: " + result);
                    writer3.write("Только один ноль. Сумма всех элементов: " + result);
                }
                else {
                    if (secondZeroIndex - firstZeroIndex == 1) {
                        result = 0;
                        System.out.println("Нули идут подряд. Результат: " + result);
                        writer3.write("Нули идут подряд. Результат: " + result);
                    } else {
                        int sum = 0;
                        for (int i = firstZeroIndex + 1; i < secondZeroIndex; i++) {
                            sum += task3[i];
                        }
                        result = sum;
                        System.out.println("Сумма между первыми двумя нулями: " + result);
                        writer3.write("Сумма между первыми двумя нулями: " + result);
                    }
                }
            }
            writer3.flush();
        }
        catch(IOException ex)
        {
            System.out.println(ex.getMessage());
        }

        System.out.println();

        //Вводится строка, состоящая из слов разделенных точками.
        // Длина строки может быть разной.
        // Сформировать и вывести подстроку,
        // расположенную между первой и второй точками исходной строки.
        // Если в строке менее двух точек, то вывести всю исходную строку.
        System.out.println("Zadanie 4");
        String path4 = System.getProperty("user.dir") + File.separatorChar + "input4.txt";
        String inputString = "";
        try (FileReader fr4 = new FileReader(path4))
        {
            BufferedReader br4 = new BufferedReader(fr4);
            String task4s;

            while ((task4s = br4.readLine()) != null)
            {
                inputString = task4s;
                System.out.println(task4s);
            }
            fr4.close();
        }
        catch (IOException ex)
        {
            System.out.println(ex.getMessage());
        }
        try(FileWriter writer4 = new FileWriter("output4.txt", false))
        {
            String result;

            int firstDotIndex = inputString.indexOf('.');
            int secondDotIndex = inputString.indexOf('.', firstDotIndex + 1);

            if (firstDotIndex == -1 || secondDotIndex == -1) {
                result = inputString;
                System.out.println("В строке менее двух точек. Результат: " + result);
            } else {
                result = inputString.substring(firstDotIndex + 1, secondDotIndex);
                System.out.println("Подстрока между точками: " + result);
            }
            writer4.write(result);
            writer4.flush();
        }
        catch(IOException ex)
        {
            System.out.println(ex.getMessage());
        }

        System.out.println();

        //Вводится строка, содержащая цифры (от 0 до 9) и строчные латинские буквы.
        //Длина строки может быть разной.
        //Если цифры в строке упорядочены по возрастанию, то вывести число 0;
        //в противном случае вывести номер первого символа строки, нарушающего порядок.
        System.out.println("Zadanie 5");
        String path5 = System.getProperty("user.dir") + File.separatorChar + "input5.txt";
        String inputString5 = "";
        try (FileReader fr5 = new FileReader(path5))
        {
            BufferedReader br5 = new BufferedReader(fr5);
            String task5s;

            while ((task5s = br5.readLine()) != null)
            {
                inputString5 = task5s;
                System.out.println(task5s);
            }
            fr5.close();
        }
        catch (IOException ex)
        {
            System.out.println(ex.getMessage());
        }
        try(FileWriter writer5 = new FileWriter("output5.txt", false))
        {
            int result = 0;
            char prevDigit = ' ';
            boolean foundFirstDigit = false;

            for (int i = 0; i < inputString5.length(); i++) {
                char c = inputString5.charAt(i);
                if (c >= '0' && c <= '9') {
                    if (!foundFirstDigit) {
                        prevDigit = c;
                        foundFirstDigit = true;
                    } else {
                        if (c <= prevDigit) {
                            result = i + 1;
                            break;
                        }
                        prevDigit = c;
                    }
                }
            }
            writer5.write(String.valueOf(result));
            System.out.println("Результат: " + result);
            writer5.flush();
        }
        catch(IOException ex)
        {
            System.out.println(ex.getMessage());
        }
    }
}