import integer_tasks.*;
import string_tasks.*;

import java.util.Random;
import java.util.Scanner;
import java.util.concurrent.ExecutorService;

public class Main {
    public static void main(String[] args) {
        //Ввести целое положительное трехзначное число N (N>0).
        // Проверить истинность высказывания:
        // "Сумма всех цифр введенного числа равна произведению первой и третьей цифры введенного числа".
        try
        {
            Scanner scr1 = new Scanner(System.in);
            System.out.println("Задание 1");
            System.out.println("Введите целое положительное 3х значное число N");

            int N = scr1.nextInt();
            if (N >= 100 && N <= 999)
            {
                task1 task1 = new task1();
                System.out.println(task1.task1func(N));
            }
            else
            {
                System.out.println("Число вне диапазона");
            }
        }
        catch (Exception ex)
        {
            System.out.println(ex.getMessage());
        }

        System.out.println();

        //С некоторого момента прошло N дней (N > 0).
        // Сколько полных недель прошло за этот период?
        try
        {
            Scanner scr2 = new Scanner(System.in);
            System.out.println("Задание 2");
            System.out.println("Введите число дней(N > 0)");

            int N = scr2.nextInt();
            if(N >= 1)
            {
                task2 task2 = new task2();
                System.out.println("Число полных недель: " + task2.task2func(N));
            }
            else
            {
                System.out.println("Число вне диапазона");
            }
        }
        catch (Exception ex)
        {
            System.out.println(ex.getMessage());
        }

        System.out.println();

        //В вещественном массиве хранятся сведения о количестве осадков,
        // выпавших за каждый день месяца N (в месяце должно быть 30 дней).
        // Определить общее количество осадков,
        // выпавших за каждую декаду этого месяца (декада состоит из 10 дней).
        try
        {
            Scanner scr3 = new Scanner(System.in);
            System.out.println("Задание 3");
            System.out.println("Введите число дней в месяце (30)");

            int N = scr3.nextInt();
            if (N == 30)
            {
                int[] intarray = new int[N];
                Random rand = new Random();

                for (int i = 0; i < N; i++)
                {
                    intarray[i] = rand.nextInt(0,50);
                }

                System.out.println("Массив");

                for (int i = 0; i < N; i++)
                {
                    System.out.printf(intarray[i] + " ");
                }

                System.out.println();

                System.out.println("Количество осадков за первую декаку месяца = " + task3.task3first(intarray));
                System.out.println("Количество осадков за вторую декаку месяца = " + task3.task3second(intarray));
                System.out.println("Количество осадков за третью декаку месяца = " + task3.task3third(intarray));

                System.out.println("Общее кол-во осадков за месяц = " + (task3.task3first(intarray) + task3.task3second(intarray) + task3.task3third(intarray)));
            }
            else
            {
                System.out.println("Неверное число дней");
            }
        }
        catch (Exception ex)
        {
            System.out.println(ex.getMessage());
        }

        System.out.println();

        // Написать функцию bool IsSquare(K) логического типа,
        // возвращающую True,
        // если целый параметр K (K > 0) является квадратом некоторого целого числа,
        // и False в противном случае.
        try
        {
            Scanner scr4 = new Scanner(System.in);
            System.out.println("Задание 4");
            System.out.println("Введите целое положительное число K");

            int K = scr4.nextInt();
            if(K >= 1)
            {
                task4 task4 = new task4();
                System.out.println(task4.IsSquare(K));
            }
            else
            {
                System.out.println("Число вне диапазона");
            }
        }
        catch (Exception ex)
        {
            System.out.println(ex.getMessage());
        }

        System.out.println();

        //Вводится строка.
        // Длина строки может быть разной.
        // Подсчитать количество содержащихся в ней строчных букв латинского алфавита.
        try
        {
            Scanner scr5 = new Scanner(System.in);
            System.out.println("Задание 5");
            System.out.println("Введите строку");

            String str = scr5.nextLine();
            System.out.println(task5.task5func(str));
        }
        catch (Exception ex)
        {
            System.out.println(ex.getMessage());
        }
    }
}