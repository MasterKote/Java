package integer_tasks;

public class task1 {
    public static boolean task1func(int N)
    {
        int sum = 0;
        int proizved = 1;

        int digit1 = (N / 100) % 10;
        int digit2 = (N / 10) % 10;
        int digit3 = N % 10;

        proizved = digit1 * digit3;
        sum = digit1 + digit2 + digit3;

        if (proizved == sum)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
}
