package integer_tasks;

public class task3 {
    public static int task3first(int[] intarray)
    {
        int firstdecade = 0;

        for (int i = 0; i < intarray.length; i++)
        {
            if (i <= 10)
            {
                firstdecade += intarray[i];
            }
        }

        return firstdecade;
    }

    public static int task3second(int[] intarray)
    {
        int seconddecade = 0;

        for (int i = 0; i < intarray.length; i++)
        {
            if (i <= 20 && i > 10)
            {
                seconddecade += intarray[i];
            }
        }

        return seconddecade;
    }

    public static int task3third(int[] intarray)
    {
        int thirddecade = 0;

        for (int i = 0; i < intarray.length; i++)
        {
            if (i <= 30 && i > 20)
            {
                thirddecade += intarray[i];
            }
        }

        return thirddecade;
    }
}