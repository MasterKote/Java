package integer_tasks;

public class task2 {
    public static int task2func(int N)
    {
       int nedeli = Math.abs(N / 7);
       return nedeli;
    }
}
