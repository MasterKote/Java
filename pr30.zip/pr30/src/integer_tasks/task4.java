package integer_tasks;

public class task4 {
    public static boolean IsSquare(int K)
    {
        double sqrt = Math.sqrt(K);
        return sqrt % 1 == 0;
    }
}
