import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        try
        {
            Scanner scr = new Scanner(System.in);
            //Проверить истинность высказывания:
            // "Сумма цифр данного положительного трехзначного числа является нечетным числом".
            System.out.println("Zadanie 1");
            System.out.println("Введите трехзначное положительное число:");
            int chislozad1 = scr.nextInt();
            if (chislozad1 >= 100 && chislozad1 <= 999)
            {
                int digit1 = (chislozad1 / 100) % 10;
                int digit2 = (chislozad1 / 10) % 10;
                int digit3 = chislozad1 % 10;
                int summofdigits = digit1 + digit2 + digit3;
                if (summofdigits %2 != 0)
                {
                    System.out.println("True");
                }
                else
                {
                    System.out.println("False");
                }
            }
            else
            {
                System.out.println("Число вне диапазона!");
            }

        }
        catch (Exception ex)
        {
            System.out.println(ex);
        }


        try
        {
            Scanner scr1 = new Scanner(System.in);
            //Дан целочисленный массив, состоящий из N элементов (N > 0).
            // Сложить со всеми четными числами максимальное нечетное число из этого массива.
            // Вывести новый полученный массив.
            System.out.println("Zadanie 2");
            System.out.println("Введите кол-во элементов массива N(не менее 30):");
            int N = scr1.nextInt();
            if (N >= 30)
            {
                Random rand = new Random();
                int[] arrayint = new int[N];
                for(int i = 0; i < N; i++)
                {
                    arrayint[i] += rand.nextInt(-50,50);
                }

                System.out.println("Массив");
                for (int i = 0; i<N ; i++)
                {
                    System.out.print(arrayint[i]+" ");
                }

                int maxnechet = 0;
                for(int i = 0; i < N ; i++)
                {
                    if (arrayint[i] > maxnechet)
                    {
                        if (arrayint[i] %2 != 0)
                        {
                            maxnechet = arrayint[i];
                        }
                    }
                }
                for(int i = 0 ; i < N ; i++)
                {
                    if (arrayint[i] %2 == 0)
                    {
                        arrayint[i] += maxnechet;
                    }
                }

                System.out.println("Массив");
                for (int i = 0; i<N ; i++)
                {
                    System.out.print(arrayint[i]+" ");
                }
            }
            else
            {
                System.out.println("Кол-во элементов должно быть больше 30!");
            }
        }
        catch (Exception ex)
        {
            System.out.println(ex);
        }

        try
        {
            Scanner scr2 = new Scanner(System.in);
            //Дан целочисленный массив, признак его завершения - число 0.
            // Размер массива может быть разный.
            // Вывести сумму всех положительных четных чисел из данного массива.
            // Если требуемые числа в наборе отсутствуют, то вывести 0.
            System.out.println("Zadanie 3");
            int N = scr2.nextInt();
            if (N >= 30)
            {
                Random rand = new Random();
                int[] intarray = new int[N];
                for(int i = 0; i < N; i++)
                {
                    intarray[i] += rand.nextInt(-50,50);
                }
            }
            else
            {
                System.out.println("Кол-во элементов должно быть больше или равно 30!");
            }
        }
        catch (Exception ex)
        {
            System.out.println(ex);
        }
    }
}