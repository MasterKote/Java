import java.lang.reflect.Array;
import java.util.Random;
import java.util.Scanner;

public class Main {
    static boolean zadanie1(int A, int B, int C)
    {
        if (A > 0 && B > 0 && C > 0)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    static int[] zadanie2(int[] intarray)
    {
        int[] newintarray = intarray;
        int firstelement = Array.getInt(intarray, 0);

        for (int i=1; i < intarray.length-1; i++)
        {
            if(newintarray[i] %2 == 0)
            {
                intarray[i] += firstelement;
            }
        }

        return newintarray;
    }

    static int Max3(int A,int B,int C)
    {
        return Math.max(A, Math.max(B, C));
    }

    static double DegToRad(double D)
    {
        return (Math.PI * D)/180;
    }

    public static void main(String[] args) {
        //Даны три целых числа: A, B, C.
        // Проверить истинность высказывания: «Каждое из чисел A, B, C положительное».
        try {
            Scanner scr1 = new Scanner(System.in);

            System.out.println("Zadanie 1");

            System.out.println("Введите положительное число A");
            int A = scr1.nextInt();

            System.out.println("Введите положительное число B");
            int B = scr1.nextInt();

            System.out.println("Введите положительное число C");
            int C = scr1.nextInt();

            System.out.println(zadanie1(A, B, C));
        }
        catch (Exception ex)
        {
            System.out.println(ex.getMessage());
        }

        //Дан целочисленный массив, состоящий из N элементов (N > 0).
        // Преобразовать массив, прибавив к четным числам первый элемент.
        // Первый и последний элементы массива не изменять.
        // Вывести новый полученный массив.
        try
        {
            Scanner scr2 = new Scanner(System.in);

            System.out.println("Zadanie 2");
            System.out.println("Введите число элементов массива N(не менее 25)");

            int N = scr2.nextInt();
            if (N >= 25) {
                int[] intarray = new int[N];
                int[] newintarray = new int[N];
                Random rand = new Random();

                for (int i = 0; i < N; i++) {
                    intarray[i] = rand.nextInt(-50, 50);
                }

                System.out.println("Массив:");
                for (int i = 0; i < N; i++) {
                    System.out.printf(intarray[i] + " ");
                }

                System.out.println();
                newintarray = zadanie2(intarray);

                System.out.println("Изменённый массив:");
                for (int i = 0; i < N; i++) {
                    System.out.printf(newintarray[i] + " ");
                }

                System.out.println();
            }
            else
            {
                System.out.println("Количество элементов должно быть не менее 25!");
            }
        }
        catch (Exception ex)
        {
            System.out.println(ex.getMessage());
        }

        //Написать функцию int Max3(A, B, C) целого типа,
        //возвращающую одно максимальное значение из 3-х своих аргументов (параметры A, B, C - целые числа).
        try
        {
            Scanner scr3 = new Scanner(System.in);

            System.out.println("Zadanie 3");
            System.out.println("Введите число A");
            int A = scr3.nextInt();
            System.out.println("Введите число B");
            int B = scr3.nextInt();
            System.out.println("Введите число C");
            int C = scr3.nextInt();

            System.out.println("Максимальное значение среди трёх чисел: " + Max3(A, B, C));
        }
        catch (Exception ex)
        {
            System.out.println(ex.getMessage());
        }

        //Написать функцию double DegToRad(D) вещественного типа,
        // находящую величину угла в радианах,
        // если дана его величина D в градусах (D — вещественное число, 0 ≤ D ≤ 360).
        // Воспользоваться следующим соотношением: 180° = pi радианов.
        // В качестве значения PI использовать предопределенную константу из библиотеки языка программирования.
        try
        {
            Scanner scr4 = new Scanner(System.in);

            System.out.println("Zadanie 4");
            System.out.println("Введите число D(не меньше 0 и не больше 360)");

            double D = scr4.nextDouble();
            if(D >= 0 && D <= 360)
            {
                System.out.println("Градусы в радианах = " + DegToRad(D));
            }
            else
            {
                System.out.println("Число D должно быть не меньше 0 и не больше 360!");
            }
        }
        catch (Exception ex)
        {
            System.out.println(ex.getMessage());
        }
    }
}