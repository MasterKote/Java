import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scr = new Scanner(System.in);

        //Проверить истинность высказывания:
        // "Квадратное уравнение A·x2 + B·x + C = 0
        // с данными коэффициентами A (A не равно 0), B, C имеет ровно один вещественный корень".
        System.out.println("Zadanie 1");

        System.out.println("Введите число A");
        int A = scr.nextInt();

        if (A != 0)
        {
            System.out.println("Введите число B");
            int B = scr.nextInt();

            System.out.println("Введите число C");
            int C = scr.nextInt();

            double discrim = Math.pow(B, 2) - (4*A*C);

            if (discrim == 0)
            {
                System.out.println("True");
            }
            else
            {
                System.out.println("False");
            }
        }
        else
        {
            System.out.println("A не должно быть 0!");
        }

        //Даны ненулевые числа x, y.
        // Проверить истинность высказывания: «Точка с координатами (x, y) лежит в первой или третьей координатной четверти».
        System.out.println("Zadanie 2");

        System.out.println("Введите число X");
        int X = scr.nextInt();

        System.out.println("Введите число Y");
        int Y = scr.nextInt();

        if (X > 0 && Y > 0)
        {
            System.out.println("True");
        }
        else if (X < 0 && Y < 0)
        {
            System.out.println("True");
        }
        else
        {
            System.out.println("False");
        }

        //Задано целое положительное четырехзначное число N (N > 0).
        // Найти разницу между суммой всех его цифр и произведением нечетных цифр.
        System.out.println("Zadanie 3");

        System.out.println("Ввежите целое положительное 4х значное число");
        int N = scr.nextInt();

        if (N >= 1000 && N <= 9999)
        {
            boolean check = false;
            int digit1 = (N / 1000) % 10;
            int digit2 = (N / 100) % 10;
            int digit3 = (N / 10) % 10;
            int digit4 = N % 10;

            int sumofdigits = digit1 + digit2 + digit3 + digit4;
            int proizvedofdigits = 1;
            if(digit1 %2 != 0)
            {
                proizvedofdigits *= digit1;
                check = true;
            }
            if(digit2 %2 != 0)
            {
                proizvedofdigits *= digit2;
                check = true;
            }
            if(digit3 %2 != 0)
            {
                proizvedofdigits *= digit3;
                check = true;
            }
            if(digit4 %2 != 0)
            {
                proizvedofdigits *= digit4;
                check = true;
            }
            if(check == true)
            {
                System.out.println(Math.abs(sumofdigits - proizvedofdigits));
            }
            else
            {
                System.out.println(Math.abs(sumofdigits));
            }
        }
        else
        {
            System.out.println("Число должно быть 4х значное целое положительное!");
        }

        //Задано целое положительное четырехзначное число N (N > 0).
        // Найти разницу между суммой всех его цифр и произведением четных цифр.
        System.out.println("Zadanie 4");

        System.out.println("Ввежите целое положительное 4х значное число");
        int N1 = scr.nextInt();

        if (N1 >= 1000 && N1 <= 9999)
        {
            boolean check = false;
            int digit1 = (N1 / 1000) % 10;
            int digit2 = (N1 / 100) % 10;
            int digit3 = (N1 / 10) % 10;
            int digit4 = N1 % 10;

            int sumofdigits = digit1 + digit2 + digit3 + digit4;
            int proizvedofdigits = 1;
            if(digit1 %2 == 0)
            {
                proizvedofdigits *= digit1;
                check = true;
            }
            if(digit2 %2 == 0)
            {
                proizvedofdigits *= digit2;
                check = true;
            }
            if(digit3 %2 == 0)
            {
                proizvedofdigits *= digit3;
                check = true;
            }
            if(digit4 %2 == 0)
            {
                proizvedofdigits *= digit4;
                check = true;
            }
            if(check == true)
            {
                System.out.println(Math.abs(sumofdigits - proizvedofdigits));
            }
            else
            {
                System.out.println(Math.abs(sumofdigits));
            }
        }
        else
        {
            System.out.println("Число должно быть 4х значное целое положительное!");
        }

        //Единицы длины пронумерованы следующим образом: 1 - дециметр, 2 - километр, 3 - метр, 4 - миллиметр, 5 - сантиметр.
        // Дан номер единицы длины (целое число в диапазоне от 1 до 5) и длина отрезка в этих единицах (вещественное число).
        // Найти длину отрезка в метрах.
        System.out.println("Zadanie 5");

        System.out.println("Введите длину отрезка");
        double length = scr.nextDouble();

        System.out.println("Введите номер единицы длины: 1 - дециметр, 2 - километр, 3 - метр, 4 - миллиметр, 5 - сантиметр");
        int vibor = scr.nextInt();

        switch (vibor)
        {
            case 1:
            {
                System.out.println("Дециметры в метрах: " + length/10);
                break;
            }
            case 2:
            {
                System.out.println("Километры в метрах: " + length*1000);
                break;
            }
            case 3:
            {
                System.out.println("Метры в метрах: " + length);
                break;
            }
            case 4:
            {
                System.out.println("Миллиметры в метрах: " + length/1000);
                break;
            }
            case 5:
            {
                System.out.println("Сантимерты в метрах: " + length/100);
                break;
            }
            default:
                System.out.println("Выбран недействительный параметр");
                break;
        }
    }
}